#imports
from random import *
from casioplot import *


#startup
def start():
  print("Power Graphic 3 Unit")
  print("Screen:127*62")
  print("BlueArchive on CASIO")
  print(" NEXON Games\n MX Studio\n MCBStudios")

def mainmenu():
  
  print("****Archive MENU****")  
  print("1-show logo")
  print("2-battlefield")
  print("3-cafe")
  print("4-archive")
  print("")  

#MAIN
start()
input("Any Key")
for i in range(114514):
  mainmenu()
  console=int(input("->"))
  while console==1:
    from logo import *
    from logo2 import *
    logo()
    logo2()
    show_screen()
  while console==2:
    from ba import *
    battle()
  while console==3:
    from cafe import *
    cafe()
  while console==4:
    print("Coming soon!")
    console=int(input("->"))
  else :
    print("Invalid Command")
