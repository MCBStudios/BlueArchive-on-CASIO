from random import *
from math import *
from baac import *
seed=randint(0,114514)
#enemy data
enna=["Helmet","Drone","Decagrammaton"]
enda=[[[[4,6],[10,13]],[[6,9],[11,12]],[[4,5],[15,17]]],[[[6,8],[13,15]],[[7,10],[12,13]],[[5,6],[17,19]]]]
enhp=[0,0,0]
enty=[0,0,0]
entt=len(enty)
dara=1.5
ensk=["cure bolt","dark dance","blank fog"]
cool=[[3,4],[3,5],[4,5]]
enco=[0,0,0]
blind=-1
#player data
dfhp=[15,22,18]
plhp=dfhp
plna=["KAYOKO","HOSHINO","HIBIKI"]
plat=[[4,6],[3,5],[5,7]]
plmp=0
skna=["fearshot","I.F.F","iron horus","Firework","cure"]
plsk=[[0,1],[2,4],[3]]
skco=[10,9,3,6,6]
sktt=len(skna)
plra=[1,1,1]
now_on=0
choo=[0,1,2]
pltt=len(choo)
#program data
chac=1
difi=0
dina=["easy","normal","master","demon"]
ditt=len(enda)
mpad=0.7
#program
def battle():
  global difi
  global enhp
  global enty
  global chac
  global plhp
  global dara
  global blind
  global now_on
  global plmp
  plmp=0
  blind=-1
  dara=1
  chac=1
  plhp=[dfhp[i] for i in range(pltt)]
  cc=1
  for i in range(entt):
    enco[i]=randint(cool[i][0],cool[i][1])
  while cc:
    dipr()
    inn=int(input())
    if inn>=0 and inn<=ditt:
      difi=inn
      cc=0
    else:
      print("out of range")  
  print("enemy arrived!")
  for i in range(len(enty)):
    enty[i]=randint(0,entt-1)
    a=enda[difi][enty[i]][1][0]
    b=enda[difi][enty[i]][1][1]
    enhp[i]=randint(int(a),int(b))
    print(enna[enty[i]]+" HP:"+str(enhp[i]))
  input()
  while chac:  
    print("enemies:")
    for i in range(pltt):
      now_on=i
      plac()
      if chac==0:
        break
    enac()
  input()
def enpr():
  for i in range(len(enty)):
    if enhp[i]>0:
      print(str(i)+":"+enna[enty[i]]+" HP:"+str(enhp[i]))
def dipr():
  for i in range(ditt):
    print(str(i)+":"+dina[i])
def skpr():
  for i in range(len(plsk[now_on])):
    print(str(i)+":"+skna[plsk[now_on][i]]+" cost:"+str(skco[plsk[now_on][i]]))    
def chpr():
  for i in range(pltt):
    if plhp[i]>0:
      print(str(i)+":"+plna[choo[i]])
    
#battle()