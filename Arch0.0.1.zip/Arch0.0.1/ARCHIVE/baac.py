import ba
from ski import *
from math import *
from random import *
def plac():
  f=1
  while f:
    ba.enpr()
    no=ba.choo[ba.now_on]
    print("self HP:"+str(ba.plhp[ba.now_on])+" MP:"+str(ba.plmp))
    print(ba.plna[no]+"'s round!")
    print("1:attack 2:skills")
    inp=input()
    if inp=="1":
      ba.enpr()
      print("choose target:",end="")
      inpp=int(input())
      if inpp<ba.entt and ba.enhp[inpp]>0:
        dama=ceil(randint(ba.plat[no][0],ba.plat[no][1])*ba.plra[no])
        ba.enhp[inpp]-=dama
        print("damaged:"+str(dama))
        f=0        
      else:
        print("out of range")
    elif inp=="2":
      ba.skpr()  
      print("choose skill:",end="")
      innn=int(input())
      if innn>=0 and innn<len(ba.plsk[no]):
        if ba.plmp>=ba.skco[ba.plsk[ba.now_on][innn]]:
          ba.plmp-=ba.skco[ba.plsk[ba.now_on][innn]]
          skac(ba.now_on,ba.plsk[ba.now_on][innn])
          f=0
        else:
          print("MP is not enough")
      else:
        print("out of range")
    else:
      print("invaild command")
    input()
  fl=1
  for i in range(ba.entt):
    if ba.enhp[i]>0:
      fl=0
  if fl:
    ba.chac=0
    print("you win!")
    return
def enac():
  ba.mptt=0
  for i in range(ba.entt):
    if ba.blind==i:
      continue
    if ba.enco[i]<=0 and ba.enhp[i]>0:
      ensk(i)
      ba.enco[i]=randint(ba.cool[i][0],ba.cool[i][1])
      input()
    elif ba.enhp[i]>0:
      dama=randint(ba.enda[ba.difi][ba.enty[i]][0][0],ba.enda[ba.difi][ba.enty[i]][0][1])
      tar=randint(0,ba.pltt-1)
      while ba.plhp[tar]<0:
        tar=randint(0,ba.pltt-1)
      ba.plhp[tar]-=ceil(dama*ba.dara)
      print(ba.enna[ba.enty[i]]+" attacked\n"+ba.plna[ba.choo[tar]]+"damaged:"+str(dama))
      ba.mptt+=ceil(dama*ba.mpad)
      ba.enco[i]-=1
      che=0
      for i in range(ba.pltt):
        if ba.plhp[i]<=0:
          che+=1
      if che==ba.pltt:
        print("you died")
        ba.chac=0
        return
      input()
  print("MP added:"+str(ba.mptt))
  ba.plmp+=ba.mptt
  if ba.plmp>40:
    ba.plmp=20
  input()
def ensk(enn):
  for i in range(ba.pltt):
    ba.plra=1
  
  en=ba.enty[enn]
  print(ba.enna[en]+" used "+ba.ensk[en])
  if en==0:
    for i in range(ba.entt):
      ba.enhp[i]+=5
  elif en==1:
    for i in range(ba.pltt):
      ba.plhp[i]-=7
    print("all damaged:7!")
  elif en==2:
    tar=randint(0,ba.pltt-1)
    while ba.plhp[tar]<0:
      tar=randint(0,ba.pltt-1)
    print(ba.plna[ba.choo[tar]]+"'s damage fell!")
    ba.plra[tar]=0.5  