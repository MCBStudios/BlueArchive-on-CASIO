from random import *
seed(randint(0,114514))
def cafe():
  print("---------------------")
  print("--S.C.H.A.L.E  Cafe--")
  print("---------------------")
  print("Insert Code:")
  print("If Code not given,\ninput 000000000")
  seccod=input("->")
  namelist=[["KAYOKO",0],["SHIROKO",0],["NONOMI",0],["HIBIKI",0],["IZUNA",0],["ARIS",0],["MOMOI",0],["HINA",0],["ARU",0]]
  for i in range(8):
    namelist[i][1]=int(tuple(seccod)[i])
    i=i+1
  #print(namelist)  
  p1=randint(0,8)
  namelist[p1][1]=namelist[p1][1]+1
  p2=randint(0,8)
  namelist[p2][1]=namelist[p2][1]+1
  p3=randint(0,8)
  namelist[p3][1]=namelist[p3][1]+1
  print("Visitors:")
  print(namelist[p1])
  print(namelist[p2])
  print(namelist[p3])
  input("Accept?[y/y]")
  print("Select Command:")
  print("1-Invitation")
  print("2-Printall")
  print("3-EXIT")
  command=int(input("->"))
  while command==1:
    print(namelist)
    person=int(input("Send invitation:"))
    namelist[person][1]=namelist[person][1]+1
    print(namelist[person])
    command=int(input("->"))
    if command==1:
      print("Short Of Tickets")
      command=int(input("->"))
    
  while command==2:
    print(namelist)
    command=int(input("->"))
  while command==3:
    print("*******WARNING*******")
    print("*REMEMBER CODE BELOW*")
    for i in range(9):
      print(namelist[i-1][1],end="")
    #print(namelist[8][1])
    input("Press Any Key")
    return