def mainmenu():
  print("****Archive MENU****")  
  print("1-show logo")
  print("2-battlefield")
  print("3-cafe")
  print("4-archive")
  
 
  
