import ba as ba
def skac(peo,ski):
  if ski==0:
    ba.enpr()
    print("choose target:",end="")
    inpp=int(input())
    while not(inpp>=0 and inpp<=ba.entt and ba.enhp[inpp]>0):
      ba.enpr()
      print("out of range")
      inpp=int(input())
    dama=10
    ba.enhp[inpp]-=dama
    print("damaged:"+str(dama))
  elif ski==1:
    print("hp all added 5")
    for i in range(ba.pltt):
      ba.plhp[i]+=5
  elif ski==2:
    print("enemies' damage fell!")
    ba.dara=0.8
  elif ski==3:
    for i in range(ba.entt):
      ba.enhp[i]-=7
    print("damaged all:7")
  elif ski==4:
    ba.chpr()
    print("choose target")
    inpp=int(input())
    while not(inpp>=0 and inpp<ba.pltt):
      print("out of range")
      inpp=int(input())
    if ba.plhp[inpp]<0:
      ba.plhp[inpp]=0
    ba.plhp[inpp]+=8
    print(ba.plna[ba.choo[inpp]]+"was cured")
