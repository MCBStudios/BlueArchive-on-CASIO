#startup
def start():
  print("Power Graphic 3 Unit")
  print("Screen:127*62")
  print("BlueArchive on CASIO")
  print(" NEXON Games\n MX Studio\n MCBStudios")
